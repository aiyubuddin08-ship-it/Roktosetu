package com.example.ui.screens.donors

import android.Manifest
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material.icons.filled.PersonPinCircle
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.BuildConfig
import com.example.domain.LocationHelper
import com.example.model.BloodGroup
import com.example.model.DonorAvailability
import com.example.model.PublicDonorView
import com.example.model.VerificationStatus
import com.example.ui.components.AuthRequiredDialog
import com.example.ui.components.BloodGroupBadge
import com.example.ui.theme.BloodSuccessContainer
import com.example.ui.theme.BloodSuccessGreen
import com.example.ui.theme.EmergencyRed
import com.example.ui.theme.EmergencyRedContainer
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.BloodViewModel
import com.example.ui.viewmodel.ChatViewModel
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.Circle
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapType
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState
import kotlinx.coroutines.launch

/**
 * Full-screen interactive Google Maps screen displaying available blood donors
 * in the user's immediate vicinity.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DonorMapScreen(
    authViewModel: AuthViewModel,
    bloodViewModel: BloodViewModel,
    chatViewModel: ChatViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToChatConversation: (String, String, String) -> Unit,
    onNavigateToLogin: () -> Unit = {},
    onNavigateToRegister: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val currentUserProfile by authViewModel.currentUserProfile.collectAsState()
    val bloodState by bloodViewModel.uiState.collectAsState()

    var hasLocationPermission by remember {
        mutableStateOf(LocationHelper.hasLocationPermission(context))
    }
    var selectedRadiusKm by remember { mutableDoubleStateOf(15.0) }
    var selectedDonor by remember { mutableStateOf<PublicDonorView?>(null) }
    var mapType by remember { mutableStateOf(MapType.NORMAL) }
    var showAuthPromptDialog by remember { mutableStateOf(false) }
    var activeVicinityLabel by remember { mutableStateOf("Dhaka Vicinity") }

    val isApiKeyConfigured = remember {
        val key = BuildConfig.MAPS_API_KEY
        key.isNotBlank() && key != "DEFAULT_API_KEY" && key != "MY_MAPS_API_KEY"
    }
    var showApiKeyNotice by remember { mutableStateOf(!isApiKeyConfigured) }

    val userLatLng = LatLng(bloodState.userLat, bloodState.userLon)
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(userLatLng, 13.2f)
    }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        hasLocationPermission = granted
        if (granted) {
            LocationHelper.fetchDeviceLocation(
                context = context,
                onResult = { lat, lon ->
                    bloodViewModel.setLocation(lat, lon)
                    activeVicinityLabel = "Live GPS Location"
                    scope.launch {
                        cameraPositionState.animate(
                            CameraUpdateFactory.newLatLngZoom(LatLng(lat, lon), 14f)
                        )
                    }
                },
                onError = { msg ->
                    scope.launch {
                        snackbarHostState.showSnackbar(msg)
                    }
                }
            )
        } else {
            scope.launch {
                snackbarHostState.showSnackbar("লোকেশন পারমিশন ছাড়া ডিফল্ট ঢাকা এরিয়া দেখানো হচ্ছে।")
            }
        }
    }

    // Request device location automatically on first open if permission is already granted
    LaunchedEffect(Unit) {
        if (hasLocationPermission) {
            LocationHelper.fetchDeviceLocation(
                context = context,
                onResult = { lat, lon ->
                    bloodViewModel.setLocation(lat, lon)
                    activeVicinityLabel = "Live GPS Location"
                    scope.launch {
                        cameraPositionState.animate(
                            CameraUpdateFactory.newLatLngZoom(LatLng(lat, lon), 13.5f)
                        )
                    }
                }
            )
        }
    }

    // Filter donors in vicinity
    val vicinityDonors = remember(bloodState.donors, selectedRadiusKm, bloodState.userLat, bloodState.userLon) {
        bloodState.donors.filter { donor ->
            val dist = donor.distanceKm ?: LocationHelper.calculateDistanceKm(
                bloodState.userLat,
                bloodState.userLon,
                donor.latitude,
                donor.longitude
            )
            selectedRadiusKm >= 100.0 || dist <= selectedRadiusKm
        }
    }

    if (showAuthPromptDialog) {
        AuthRequiredDialog(
            title = "চ্যাট করতে সাইন ইন করুন",
            message = "রক্তদাতার সাথে সরাসরি মেসেজে কথা বলতে অনুগ্রহ করে লগইন বা রেজিস্ট্রেশন করুন।",
            onDismiss = { showAuthPromptDialog = false },
            onNavigateToLogin = onNavigateToLogin,
            onNavigateToRegister = onNavigateToRegister
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Nearby Blood Donors Map",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "কাছাকাছি রক্তদাতা ম্যাপ • $activeVicinityLabel (${vicinityDonors.size} found)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("btn_map_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            mapType = when (mapType) {
                                MapType.NORMAL -> MapType.HYBRID
                                MapType.HYBRID -> MapType.TERRAIN
                                else -> MapType.NORMAL
                            }
                        },
                        modifier = Modifier.testTag("btn_toggle_map_type")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Layers,
                            contentDescription = "Toggle Map Layer",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // 1. Google Map View
            GoogleMap(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("google_map_donors"),
                cameraPositionState = cameraPositionState,
                properties = MapProperties(
                    isMyLocationEnabled = hasLocationPermission,
                    mapType = mapType
                ),
                uiSettings = MapUiSettings(
                    zoomControlsEnabled = false,
                    myLocationButtonEnabled = false,
                    compassEnabled = true,
                    mapToolbarEnabled = true
                ),
                onMapClick = {
                    selectedDonor = null
                }
            ) {
                // User's current search center marker
                Marker(
                    state = MarkerState(position = userLatLng),
                    title = "Your Search Center ($activeVicinityLabel)",
                    snippet = "Searching within ${if (selectedRadiusKm >= 100.0) "All BD" else "${selectedRadiusKm.toInt()} km"}",
                    icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)
                )

                // Vicinity radius circle
                if (selectedRadiusKm < 100.0) {
                    Circle(
                        center = userLatLng,
                        radius = selectedRadiusKm * 1000.0,
                        fillColor = Color(0x22D32F2F),
                        strokeColor = Color(0x99D32F2F),
                        strokeWidth = 3f
                    )
                }

                // Donor Markers in Vicinity
                vicinityDonors.forEach { donor ->
                    if (donor.latitude != 0.0 && donor.longitude != 0.0) {
                        val markerHue = when {
                            donor.availability == DonorAvailability.AVAILABLE && donor.isEmergencyDonor ->
                                BitmapDescriptorFactory.HUE_RED
                            donor.availability == DonorAvailability.AVAILABLE ->
                                BitmapDescriptorFactory.HUE_GREEN
                            else ->
                                BitmapDescriptorFactory.HUE_ORANGE
                        }
                        val distLabel = donor.distanceKm?.let { "$it km away" } ?: donor.generalLocation
                        Marker(
                            state = MarkerState(position = LatLng(donor.latitude, donor.longitude)),
                            title = "${donor.bloodGroup.display} • ${donor.name}",
                            snippet = "$distLabel • Tap card below to Call/Chat",
                            icon = BitmapDescriptorFactory.defaultMarker(markerHue),
                            onClick = {
                                selectedDonor = donor
                                false
                            }
                        )
                    }
                }
            }

            // 2. Top Overlay Controls (API Key notice + Blood Group Filter + Radius & Vicinity Presets)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                AnimatedVisibility(visible = showApiKeyNotice) {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.WarningAmber,
                                contentDescription = null,
                                tint = EmergencyRed,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Add MAPS_API_KEY in AI Studio Secrets panel to load live street tiles. Donor pins & GPS controls are active.",
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { showApiKeyNotice = false },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Dismiss",
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }

                // Blood Group Filter Chips Row
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                    shadowElevation = 3.dp
                ) {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        item {
                            FilterChip(
                                selected = bloodState.selectedBloodGroupFilter == null,
                                onClick = { bloodViewModel.setBloodGroupFilter(null) },
                                label = { Text("All Blood", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                        items(BloodGroup.entries) { bg ->
                            FilterChip(
                                selected = bloodState.selectedBloodGroupFilter == bg,
                                onClick = {
                                    val next = if (bloodState.selectedBloodGroupFilter == bg) null else bg
                                    bloodViewModel.setBloodGroupFilter(next)
                                },
                                label = { Text(bg.display, fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EmergencyRed,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.testTag("map_filter_blood_${bg.name}")
                            )
                        }
                    }
                }

                // Vicinity Radius + Quick Area Jump Row
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                    shadowElevation = 3.dp
                ) {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val radii = listOf(5.0 to "5 km", 15.0 to "15 km", 30.0 to "30 km", 100.0 to "All BD")
                        items(radii) { (radiusVal, label) ->
                            FilterChip(
                                selected = selectedRadiusKm == radiusVal,
                                onClick = { selectedRadiusKm = radiusVal },
                                label = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = BloodSuccessGreen,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }

                        items(LocationHelper.KNOWN_VICINITY_PRESETS) { preset ->
                            FilterChip(
                                selected = activeVicinityLabel == preset.name,
                                onClick = {
                                    activeVicinityLabel = preset.name
                                    bloodViewModel.setLocation(preset.latitude, preset.longitude)
                                    scope.launch {
                                        cameraPositionState.animate(
                                            CameraUpdateFactory.newLatLngZoom(
                                                LatLng(preset.latitude, preset.longitude),
                                                13.8f
                                            )
                                        )
                                    }
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp)
                                    )
                                },
                                label = { Text("${preset.name} (${preset.bengaliName})", fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }

            // 3. Floating My Location Button
            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FloatingActionButton(
                    onClick = {
                        if (LocationHelper.hasLocationPermission(context)) {
                            hasLocationPermission = true
                            LocationHelper.fetchDeviceLocation(
                                context = context,
                                onResult = { lat, lon ->
                                    bloodViewModel.setLocation(lat, lon)
                                    activeVicinityLabel = "Live GPS Location"
                                    scope.launch {
                                        cameraPositionState.animate(
                                            CameraUpdateFactory.newLatLngZoom(LatLng(lat, lon), 14.2f)
                                        )
                                    }
                                },
                                onError = {
                                    scope.launch {
                                        cameraPositionState.animate(
                                            CameraUpdateFactory.newLatLngZoom(userLatLng, 13.8f)
                                        )
                                    }
                                }
                            )
                        } else {
                            locationPermissionLauncher.launch(
                                arrayOf(
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION
                                )
                            )
                        }
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("fab_my_location")
                ) {
                    Icon(
                        imageVector = Icons.Default.MyLocation,
                        contentDescription = "Locate Me (আমার অবস্থান)"
                    )
                }
            }

            // 4. Bottom Donor Carousel & Selected Donor Detail Sheet
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Selected Donor Detail Card
                selectedDonor?.let { donor ->
                    SelectedMapDonorCard(
                        donor = donor,
                        onDismiss = { selectedDonor = null },
                        onDirectionsClick = {
                            val uri = Uri.parse("geo:${donor.latitude},${donor.longitude}?q=${donor.latitude},${donor.longitude}(${Uri.encode(donor.name)})")
                            val mapIntent = Intent(Intent.ACTION_VIEW, uri)
                            context.startActivity(mapIntent)
                        },
                        onCallClick = {
                            if (donor.contactPhone.isNotBlank()) {
                                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${donor.contactPhone}"))
                                context.startActivity(intent)
                            }
                        },
                        onChatClick = {
                            if (currentUserProfile != null) {
                                chatViewModel.startChatWithDonor(
                                    donorUid = donor.uid,
                                    donorName = donor.name,
                                    donorBloodGroup = donor.bloodGroup.display,
                                    onReady = { convId ->
                                        onNavigateToChatConversation(convId, donor.name, donor.bloodGroup.display)
                                    }
                                )
                            } else {
                                showAuthPromptDialog = true
                            }
                        }
                    )
                }

                // Horizontal scrollable chips/cards of nearby donors to quickly focus on map
                if (vicinityDonors.isNotEmpty()) {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(vicinityDonors, key = { it.uid }) { donor ->
                            val isSelected = selectedDonor?.uid == donor.uid
                            ElevatedCard(
                                modifier = Modifier
                                    .width(235.dp)
                                    .clickable {
                                        selectedDonor = donor
                                        if (donor.latitude != 0.0 && donor.longitude != 0.0) {
                                            scope.launch {
                                                cameraPositionState.animate(
                                                    CameraUpdateFactory.newLatLngZoom(
                                                        LatLng(donor.latitude, donor.longitude),
                                                        15f
                                                    )
                                                )
                                            }
                                        }
                                    }
                                    .border(
                                        width = if (isSelected) 2.dp else 0.dp,
                                        color = if (isSelected) EmergencyRed else Color.Transparent,
                                        shape = RoundedCornerShape(16.dp)
                                    )
                                    .testTag("map_carousel_donor_${donor.uid}"),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.elevatedCardColors(
                                    containerColor = MaterialTheme.colorScheme.surface
                                ),
                                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    BloodGroupBadge(
                                        bloodGroup = donor.bloodGroup,
                                        sizeInDp = 42,
                                        isHighlighted = isSelected
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = donor.name,
                                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            if (donor.verificationStatus == VerificationStatus.VERIFIED) {
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Icon(
                                                    imageVector = Icons.Default.Verified,
                                                    contentDescription = "Verified",
                                                    tint = BloodSuccessGreen,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            text = donor.generalLocation,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = donor.distanceKm?.let { "$it km away • Tap to focus" } ?: "Available nearby",
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SelectedMapDonorCard(
    donor: PublicDonorView,
    onDismiss: () -> Unit,
    onDirectionsClick: () -> Unit,
    onCallClick: () -> Unit,
    onChatClick: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
            .testTag("selected_map_donor_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 8.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BloodGroupBadge(
                    bloodGroup = donor.bloodGroup,
                    sizeInDp = 52,
                    isHighlighted = true
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = donor.name,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        if (donor.verificationStatus == VerificationStatus.VERIFIED) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = "Verified Donor",
                                tint = BloodSuccessGreen,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = donor.generalLocation,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        donor.distanceKm?.let { dist ->
                            Text(
                                text = " • $dist km",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                color = EmergencyRed
                            )
                        }
                    }
                    Text(
                        text = if (donor.availability == DonorAvailability.AVAILABLE)
                            "Available for Immediate Donation • ${donor.donationCount} Donations"
                        else "Emergency Calls Only • ${donor.donationCount} Donations",
                        style = MaterialTheme.typography.labelSmall,
                        color = BloodSuccessGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onDirectionsClick,
                    modifier = Modifier.weight(1f).testTag("btn_map_directions"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Directions, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Directions", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                if (donor.contactPhone.isNotBlank()) {
                    Button(
                        onClick = onCallClick,
                        modifier = Modifier.weight(1f).testTag("btn_map_call"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BloodSuccessGreen)
                    ) {
                        Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Call", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Button(
                    onClick = onChatClick,
                    modifier = Modifier.weight(1f).testTag("btn_map_chat"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Chat", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * Reusable embedded Google Maps card for displaying nearby donors inside
 * DonorDirectoryScreen and EmergencyScreen, with an option to expand to full screen.
 */
@Composable
fun EmbeddedVicinityDonorMapCard(
    donors: List<PublicDonorView>,
    userLat: Double,
    userLon: Double,
    radiusKm: Double = 20.0,
    onUpdateUserLocation: (Double, Double) -> Unit,
    onOpenFullScreenMap: () -> Unit,
    onSelectDonorForCall: (PublicDonorView) -> Unit,
    onSelectDonorForChat: (PublicDonorView) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var hasLocationPermission by remember {
        mutableStateOf(LocationHelper.hasLocationPermission(context))
    }
    var selectedDonor by remember { mutableStateOf<PublicDonorView?>(null) }

    val centerLatLng = LatLng(userLat, userLon)
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(centerLatLng, 12.5f)
    }

    LaunchedEffect(userLat, userLon) {
        cameraPositionState.animate(
            CameraUpdateFactory.newLatLngZoom(LatLng(userLat, userLon), 12.8f)
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val granted = perms[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                perms[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        hasLocationPermission = granted
        if (granted) {
            LocationHelper.fetchDeviceLocation(
                context = context,
                onResult = { lat, lon ->
                    onUpdateUserLocation(lat, lon)
                }
            )
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("embedded_donor_map_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column {
            // Header bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PersonPinCircle,
                        contentDescription = null,
                        tint = EmergencyRed,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Live Google Map • ${donors.size} Donors Nearby",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Tap any blood pin to view donor & contact",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SmallFloatingActionButton(
                        onClick = {
                            if (LocationHelper.hasLocationPermission(context)) {
                                hasLocationPermission = true
                                LocationHelper.fetchDeviceLocation(
                                    context = context,
                                    onResult = { lat, lon -> onUpdateUserLocation(lat, lon) }
                                )
                            } else {
                                permissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.ACCESS_FINE_LOCATION,
                                        Manifest.permission.ACCESS_COARSE_LOCATION
                                    )
                                )
                            }
                        },
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(36.dp).testTag("btn_embedded_map_locate")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MyLocation,
                            contentDescription = "My Location",
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    SmallFloatingActionButton(
                        onClick = onOpenFullScreenMap,
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = Color.White,
                        modifier = Modifier.size(36.dp).testTag("btn_open_fullscreen_map")
                    ) {
                        Icon(
                            imageVector = Icons.Default.OpenInFull,
                            contentDescription = "Full Screen Map",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Map Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(270.dp)
            ) {
                GoogleMap(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("embedded_google_map"),
                    cameraPositionState = cameraPositionState,
                    properties = MapProperties(
                        isMyLocationEnabled = hasLocationPermission
                    ),
                    uiSettings = MapUiSettings(
                        zoomControlsEnabled = true,
                        myLocationButtonEnabled = false
                    )
                ) {
                    Marker(
                        state = MarkerState(position = centerLatLng),
                        title = "Your Vicinity Center",
                        icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)
                    )

                    Circle(
                        center = centerLatLng,
                        radius = radiusKm * 1000.0,
                        fillColor = Color(0x1FD32F2F),
                        strokeColor = Color(0x88D32F2F),
                        strokeWidth = 2.5f
                    )

                    donors.forEach { donor ->
                        if (donor.latitude != 0.0 && donor.longitude != 0.0) {
                            Marker(
                                state = MarkerState(position = LatLng(donor.latitude, donor.longitude)),
                                title = "${donor.bloodGroup.display} • ${donor.name}",
                                snippet = "${donor.generalLocation} (${donor.distanceKm ?: 0.0} km)",
                                icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED),
                                onClick = {
                                    selectedDonor = donor
                                    false
                                }
                            )
                        }
                    }
                }
            }

            // Selected donor quick bar if a pin was tapped
            selectedDonor?.let { donor ->
                Surface(
                    color = EmergencyRedContainer.copy(alpha = 0.45f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BloodGroupBadge(bloodGroup = donor.bloodGroup, sizeInDp = 40, isHighlighted = true)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = donor.name,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "${donor.generalLocation} • ${donor.distanceKm ?: 0.0} km",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (donor.contactPhone.isNotBlank()) {
                            IconButton(onClick = { onSelectDonorForCall(donor) }) {
                                Icon(Icons.Default.Call, contentDescription = "Call", tint = BloodSuccessGreen)
                            }
                        }
                        IconButton(onClick = { onSelectDonorForChat(donor) }) {
                            Icon(Icons.Default.Chat, contentDescription = "Chat", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}
