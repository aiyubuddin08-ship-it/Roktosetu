package com.example.domain

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.Manifest
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class VicinityAreaPreset(
    val id: String,
    val name: String,
    val bengaliName: String,
    val latitude: Double,
    val longitude: Double
)

/**
 * Domain utility for approximate distance calculation (Haversine Formula),
 * FusedLocationProviderClient real device GPS lookup, and privacy masking of exact coordinates.
 */
object LocationHelper {

    private const val EARTH_RADIUS_KM = 6371.0

    val KNOWN_VICINITY_PRESETS = listOf(
        VicinityAreaPreset("dhaka_center", "Dhaka Central", "ঢাকা কেন্দ্র", 23.7771, 90.3994),
        VicinityAreaPreset("dhanmondi", "Dhanmondi", "ধানমন্ডি", 23.7461, 90.3742),
        VicinityAreaPreset("mirpur", "Mirpur", "মিরপুর", 23.8223, 90.3654),
        VicinityAreaPreset("uttara", "Uttara", "উত্তরা", 23.8759, 90.3795),
        VicinityAreaPreset("gulshan", "Gulshan / Banani", "গুলশান / বনানী", 23.7925, 90.4078),
        VicinityAreaPreset("savar", "Savar", "সাভার", 23.8583, 90.2667),
        VicinityAreaPreset("mohammadpur", "Mohammadpur", "মোহাম্মদপুর", 23.7662, 90.3589),
        VicinityAreaPreset("motijheel", "Motijheel", "মতিঝিল", 23.7330, 90.4172),
        VicinityAreaPreset("chattogram", "Chattogram", "চট্টগ্রাম", 22.3569, 91.7832),
        VicinityAreaPreset("sylhet", "Sylhet", "সিলেট", 24.8949, 91.8687),
        VicinityAreaPreset("rajshahi", "Rajshahi", "রাজশাহী", 24.3745, 88.6042),
        VicinityAreaPreset("khulna", "Khulna", "খুলনা", 22.8456, 89.5403)
    )

    private val AREA_COORDINATES = mapOf(
        "dhanmondi" to Pair(23.7461, 90.3742),
        "mirpur" to Pair(23.8223, 90.3654),
        "uttara" to Pair(23.8759, 90.3795),
        "gulshan" to Pair(23.7925, 90.4078),
        "banani" to Pair(23.7940, 90.4043),
        "mohammadpur" to Pair(23.7662, 90.3589),
        "motijheel" to Pair(23.7330, 90.4172),
        "shahbag" to Pair(23.7381, 90.3958),
        "shahbagh" to Pair(23.7381, 90.3958),
        "savar" to Pair(23.8583, 90.2667),
        "bashundhara" to Pair(23.8191, 90.4526),
        "badda" to Pair(23.7805, 90.4267),
        "tejgaon" to Pair(23.7619, 90.3907),
        "farmgate" to Pair(23.7561, 90.3872),
        "khilgaon" to Pair(23.7507, 90.4254),
        "jatrabari" to Pair(23.7104, 90.4348),
        "rampura" to Pair(23.7612, 90.4219),
        "malibagh" to Pair(23.7502, 90.4138),
        "mohakhali" to Pair(23.7778, 90.4057),
        "lalbagh" to Pair(23.7189, 90.3882),
        "wari" to Pair(23.7176, 90.4178),
        "gazipur" to Pair(23.9999, 90.4203),
        "narayanganj" to Pair(23.6238, 90.5000),
        "chattogram" to Pair(22.3569, 91.7832),
        "chittagong" to Pair(22.3569, 91.7832),
        "sylhet" to Pair(24.8949, 91.8687),
        "rajshahi" to Pair(24.3745, 88.6042),
        "khulna" to Pair(22.8456, 89.5403),
        "barishal" to Pair(22.7010, 90.3535),
        "barisal" to Pair(22.7010, 90.3535),
        "rangpur" to Pair(25.7439, 89.2752),
        "mymensingh" to Pair(24.7471, 90.4203),
        "cumilla" to Pair(23.4607, 91.1809),
        "comilla" to Pair(23.4607, 91.1809),
        "dhaka" to Pair(23.7806, 90.4070)
    )

    /**
     * Checks if location permissions are currently granted.
     */
    fun hasLocationPermission(context: Context): Boolean {
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    /**
     * Fetches the user's real device coordinates via FusedLocationProviderClient.
     */
    @SuppressLint("MissingPermission")
    fun fetchDeviceLocation(
        context: Context,
        onResult: (Double, Double) -> Unit,
        onError: (String) -> Unit = {}
    ) {
        if (!hasLocationPermission(context)) {
            onError("Location permission not granted")
            return
        }
        try {
            val client = LocationServices.getFusedLocationProviderClient(context)
            val cts = CancellationTokenSource()
            client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.token)
                .addOnSuccessListener { location ->
                    if (location != null && (location.latitude != 0.0 || location.longitude != 0.0)) {
                        onResult(location.latitude, location.longitude)
                    } else {
                        client.lastLocation
                            .addOnSuccessListener { lastLoc ->
                                if (lastLoc != null && (lastLoc.latitude != 0.0 || lastLoc.longitude != 0.0)) {
                                    onResult(lastLoc.latitude, lastLoc.longitude)
                                } else {
                                    onError("Device GPS returned null; using default vicinity")
                                }
                            }
                            .addOnFailureListener { e ->
                                onError(e.localizedMessage ?: "Unable to fetch last location")
                            }
                    }
                }
                .addOnFailureListener {
                    client.lastLocation
                        .addOnSuccessListener { lastLoc ->
                            if (lastLoc != null && (lastLoc.latitude != 0.0 || lastLoc.longitude != 0.0)) {
                                onResult(lastLoc.latitude, lastLoc.longitude)
                            } else {
                                onError("Unable to retrieve GPS fix")
                            }
                        }
                        .addOnFailureListener { e ->
                            onError(e.localizedMessage ?: "Location lookup failed")
                        }
                }
        } catch (e: Exception) {
            onError(e.localizedMessage ?: "Location service error")
        }
    }

    /**
     * Resolves approximate coordinates for a given area/city string with privacy-safe jitter
     * so multiple donors in the same neighborhood are visible as distinct markers on Google Maps.
     */
    fun resolveCoordinatesForLocation(
        area: String,
        city: String,
        seed: String = ""
    ): Pair<Double, Double> {
        val combined = "${area.lowercase()} ${city.lowercase()}"
        val base = AREA_COORDINATES.entries.firstOrNull { (key, _) ->
            combined.contains(key)
        }?.value ?: Pair(23.7806, 90.4070) // Default Dhaka center

        if (seed.isBlank()) return base

        val hash = abs(seed.hashCode())
        val latOffset = ((hash % 140) - 70) * 0.00012
        val lonOffset = (((hash / 140) % 140) - 70) * 0.00012
        val lat = Math.round((base.first + latOffset) * 10000.0) / 10000.0
        val lon = Math.round((base.second + lonOffset) * 10000.0) / 10000.0
        return Pair(lat, lon)
    }

    /**
     * Calculates great-circle distance between two points in kilometers.
     */
    fun calculateDistanceKm(
        lat1: Double,
        lon1: Double,
        lat2: Double,
        lon2: Double
    ): Double {
        if ((lat1 == 0.0 && lon1 == 0.0) || (lat2 == 0.0 && lon2 == 0.0)) return 0.0

        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)

        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2) * sin(dLon / 2)

        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        val distance = EARTH_RADIUS_KM * c

        // Round to 1 decimal place
        return Math.round(distance * 10.0) / 10.0
    }

    /**
     * Applies privacy fuzzing/rounding to prevent exposing exact private home addresses.
     * Fuzzes coordinates to ~1 km resolution.
     */
    fun getPrivacyMaskedCoordinates(lat: Double, lon: Double): Pair<Double, Double> {
        val fuzzedLat = Math.round(lat * 100.0) / 100.0
        val fuzzedLon = Math.round(lon * 100.0) / 100.0
        return Pair(fuzzedLat, fuzzedLon)
    }
}
